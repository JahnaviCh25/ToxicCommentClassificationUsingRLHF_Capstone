# metrics.py
from model_loader import metrics_models

def compute_semantic_similarity(original, paraphrased):
    """
    Compute semantic similarity between the original and paraphrased comment using Sentence-BERT.
    Returns a similarity score between 0 and 1.
    """
    try:
        sentence_bert = metrics_models.load_sentence_bert()
        embeddings = sentence_bert.encode([original, paraphrased])
        similarity = float(embeddings[0] @ embeddings[1].T)
        return round(similarity, 2)
    except Exception as e:
        print(f"Error computing semantic similarity: {str(e)}")
        return None

def compute_empathy_score(paraphrased):
    """
    Compute an empathy score for the paraphrased comment (placeholder).
    Returns a score between 0 and 1.
    """
    try:
        # Placeholder: Compute empathy based on word presence (e.g., "sorry", "understand")
        empathy_words = ["sorry", "understand", "care", "help", "support"]
        words = paraphrased.lower().split()
        empathy_count = sum(1 for word in words if word in empathy_words)
        score = empathy_count / len(words) if words else 0
        return round(score, 2)
    except Exception as e:
        print(f"Error computing empathy score: {str(e)}")
        return None