---
title: Toxic Comment Classifier
emoji: 🏃
colorFrom: blue
colorTo: gray
sdk: gradio
sdk_version: 5.23.3
app_file: app.py
pinned: false
license: mit
short_description: Capstone
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference